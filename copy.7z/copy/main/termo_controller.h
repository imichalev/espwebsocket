
#include "esp_err.h"
#include "esp_system.h"


#define POWER_PIN 22
#define POWER_ON  1
#define POWER_OFF 0


esp_err_t controllerOn ();
